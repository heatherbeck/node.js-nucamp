module.exports = {
    'secretKey': '12345-67890-09876-54321',
    'mongoUrl': 'mongodb://localhost:27017/nucampsite',
    'facebook': {
        clientId: '1425945587591924',
        clientSecret: '4dd9d0951af7224ca7efd9637d721169'
    }
}